var searchData=
[
  ['x_0',['x',['../namespaceimagemaker.html#aa48562894517a8021d7050ee229aef1e',1,'imagemaker.x'],['../namespaceimagemaker__double.html#a81718b457e728c4446051777cd3437d2',1,'imagemaker_double.x']]],
  ['xmax_1',['xmax',['../namespaceimagemaker.html#a4a9758938035eaf71c18b43e92fa1139',1,'imagemaker.xmax'],['../namespaceimagemaker__double.html#a7170912db42c441b4bc901f0b50e9f11',1,'imagemaker_double.xmax']]]
];
