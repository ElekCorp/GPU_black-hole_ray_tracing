var searchData=
[
  ['phi_5f0_0',['phi_0',['../classkerr__black__hole.html#aae11ddb2293649c1de05d06492327bfb',1,'kerr_black_hole']]],
  ['pixels_1',['pixels',['../namespaceimagemaker.html#a82a491b59ca734114f0ddea0a82fe074',1,'imagemaker.pixels'],['../namespaceimagemaker__double.html#a665e77c2e81fe2700869614276285652',1,'imagemaker_double.pixels']]],
  ['pown_2',['pown',['../cuda__ray_8h.html#a5d51141dfdc49e86e7a9f0efe4b6a985',1,'cuda_ray.h']]]
];
