var searchData=
[
  ['d_0',['D',['../black__hole_8h.html#af316c33cc298530f245e8b55330e86b5',1,'black_hole.h']]]
];
