var searchData=
[
  ['main_0',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['makeframe_1',['makeframe',['../main_8cpp.html#a6a5b847bb19d7710d0c7325ac4a80105',1,'main.cpp']]],
  ['makeframe_5ft_2',['makeframe_T',['../main_8cpp.html#a90b5e10748bef218ea20c84d2e2cb391',1,'main.cpp']]]
];
