var searchData=
[
  ['r_0',['r',['../namespaceimagemaker.html#a8774fb2a706d3b832d5e4a416e6152a3',1,'imagemaker.r'],['../namespaceimagemaker__double.html#a85e446defb83c28fc022ec968cd73607',1,'imagemaker_double.r']]],
  ['r_5f0_1',['r_0',['../classkerr__black__hole.html#abc3f440580adb8500b7ff0f84bf8dfc3',1,'kerr_black_hole']]],
  ['ray_5fstep_2',['ray_step',['../cuda__ray_8h.html#ad85712d23e025903e711b4b2c9cda898',1,'cuda_ray.h']]],
  ['ray_5fstep_5ft_3',['ray_step_T',['../cuda__ray_8h.html#aabb86c2af6d808f77d50ac19a8b3d757',1,'cuda_ray.h']]],
  ['rk38_4',['RK38',['../cuda__ray_8h.html#a6a3fe764b33cd6dd9b0dbd2ffe3f31c7',1,'cuda_ray.h']]],
  ['rk6_5',['RK6',['../cuda__ray_8h.html#a04b47324576afe88851cfbe228d8f344',1,'cuda_ray.h']]],
  ['rs_6',['rs',['../classkerr__black__hole.html#aa365567db8c5411be76fe3b0acade0d0',1,'kerr_black_hole']]]
];
