var searchData=
[
  ['de0_0',['de0',['../classkerr__black__hole.html#a04f366421a437b0703b4b23a36b65b16',1,'kerr_black_hole']]]
];
