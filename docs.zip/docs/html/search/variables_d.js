var searchData=
[
  ['r_0',['r',['../namespaceimagemaker.html#a8774fb2a706d3b832d5e4a416e6152a3',1,'imagemaker.r'],['../namespaceimagemaker__double.html#a85e446defb83c28fc022ec968cd73607',1,'imagemaker_double.r']]],
  ['r_5f0_1',['r_0',['../classkerr__black__hole.html#abc3f440580adb8500b7ff0f84bf8dfc3',1,'kerr_black_hole']]],
  ['rs_2',['rs',['../classkerr__black__hole.html#aa365567db8c5411be76fe3b0acade0d0',1,'kerr_black_hole']]]
];
