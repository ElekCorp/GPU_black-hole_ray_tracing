var searchData=
[
  ['kerr_5fblack_5fhole_0',['kerr_black_hole',['../classkerr__black__hole.html#a0823b696c1862fb03c54231f78aa3e4b',1,'kerr_black_hole']]]
];
