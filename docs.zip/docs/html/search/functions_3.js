var searchData=
[
  ['ijk_5fto_5fn_0',['ijk_to_n',['../cuda__ray_8h.html#a34d993c7ebefca91d77db8455b498b03',1,'cuda_ray.h']]],
  ['ijk_5fto_5fvec_5fmink_5fzoom_1',['ijk_to_vec_mink_zoom',['../cuda__ray_8h.html#af439db1f1cfbccf9960c5f4d8a71575f',1,'cuda_ray.h']]],
  ['ijk_5fto_5fvec_5fzoom_2',['ijk_to_vec_zoom',['../cuda__ray_8h.html#ae39dfba68c2f340b6264a90d8d4d9d7a',1,'cuda_ray.h']]],
  ['iro_3',['iro',['../classkerr__black__hole.html#a87aa967347fe4123a258757aa8b760ae',1,'kerr_black_hole']]]
];
