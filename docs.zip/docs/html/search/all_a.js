var searchData=
[
  ['magas_0',['MAGAS',['../classkerr__black__hole.html#a095fa4719ddab298126a2d82253946c2',1,'kerr_black_hole']]],
  ['main_1',['main',['../main_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main.cpp']]],
  ['main_2ecpp_2',['main.cpp',['../main_8cpp.html',1,'']]],
  ['makeframe_3',['makeframe',['../main_8cpp.html#a6a5b847bb19d7710d0c7325ac4a80105',1,'main.cpp']]],
  ['makeframe_5ft_4',['makeframe_T',['../main_8cpp.html#a90b5e10748bef218ea20c84d2e2cb391',1,'main.cpp']]]
];
