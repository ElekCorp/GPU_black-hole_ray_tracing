var searchData=
[
  ['q_0',['Q',['../classkerr__black__hole.html#a93428c0c7b158b4ebe34966288a00fda',1,'kerr_black_hole']]]
];
