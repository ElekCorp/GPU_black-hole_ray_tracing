var searchData=
[
  ['szinsaver_2ecpp_0',['szinsaver.cpp',['../szinsaver_8cpp.html',1,'']]],
  ['szinsaver_2eh_1',['szinsaver.h',['../szinsaver_8h.html',1,'']]]
];
