var searchData=
[
  ['magas_0',['MAGAS',['../classkerr__black__hole.html#a095fa4719ddab298126a2d82253946c2',1,'kerr_black_hole']]]
];
