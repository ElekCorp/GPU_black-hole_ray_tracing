var searchData=
[
  ['gomb_5fbe_0',['gomb_be',['../cuda__ray_8h.html#a439a2fe0ed3ed8f198a4f70f2f6b6572',1,'cuda_ray.h']]],
  ['gomb_5fki_1',['gomb_ki',['../cuda__ray_8h.html#a3b25e929b33a919e14f0981254817cf7',1,'cuda_ray.h']]]
];
