var searchData=
[
  ['save_5fall_0',['save_all',['../namespaceimagemaker__double.html#a233f489c87ff782627002f0105c17f6b',1,'imagemaker_double']]],
  ['step_1',['step',['../cuda__ray_8h.html#a2759c4f17512e5c7473221e51b0d2611',1,'cuda_ray.h']]],
  ['step_5fsize_2',['step_size',['../cuda__ray_8h.html#a3b458fc5909707422ffbed296da06efd',1,'cuda_ray.h']]],
  ['sugar_5fki_3',['sugar_ki',['../classkerr__black__hole.html#a34b5d482645d3b6e2866d80328b8c6c3',1,'kerr_black_hole']]],
  ['sugar_5fkicsi_4',['sugar_kicsi',['../classkerr__black__hole.html#a75d7c70436cf1655f0d6a068362ae95f',1,'kerr_black_hole']]],
  ['sugar_5fnagy_5',['sugar_nagy',['../classkerr__black__hole.html#ae3612c59bfd95783159ca722929d6a83',1,'kerr_black_hole']]],
  ['szeles_6',['SZELES',['../classkerr__black__hole.html#a6f9f331dacd7cc08e0bdf92d0cbfb9bd',1,'kerr_black_hole']]],
  ['szinsaver_2ecpp_7',['szinsaver.cpp',['../szinsaver_8cpp.html',1,'']]],
  ['szinsaver_2eh_8',['szinsaver.h',['../szinsaver_8h.html',1,'']]]
];
