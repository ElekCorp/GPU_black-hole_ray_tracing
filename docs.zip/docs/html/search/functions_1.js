var searchData=
[
  ['datasaver_0',['datasaver',['../szinsaver_8cpp.html#ab2ca52da0f5ee9b90ba4bfd5d86f430c',1,'datasaver(int8_t *szin, int SZELES, int MAGAS, char *filename):&#160;szinsaver.cpp'],['../szinsaver_8cpp.html#a5a9482462f78c306951ac66a88da657d',1,'datasaver(int8_t *szin, int SZELES, int MAGAS, std::string &amp;filename):&#160;szinsaver.cpp'],['../szinsaver_8h.html#ab2ca52da0f5ee9b90ba4bfd5d86f430c',1,'datasaver(int8_t *szin, int SZELES, int MAGAS, char *filename):&#160;szinsaver.cpp'],['../szinsaver_8h.html#a5a9482462f78c306951ac66a88da657d',1,'datasaver(int8_t *szin, int SZELES, int MAGAS, std::string &amp;filename):&#160;szinsaver.cpp']]],
  ['datasaver_5ft_1',['datasaver_t',['../szinsaver_8h.html#af60bcb64808548eddb13b85bb990da1b',1,'datasaver_T(FP *szin, int SZELES, int MAGAS, char *filename):&#160;szinsaver.h'],['../szinsaver_8h.html#a5d5c423fb2f4e2af50b32a341be145d0',1,'datasaver_T(FP *szin, int SZELES, int MAGAS, std::string &amp;filename):&#160;szinsaver.h']]],
  ['device_5finfo_2',['device_info',['../main_8cpp.html#ae4968cd23e08f390bdd20c47ad87f241',1,'main.cpp']]],
  ['disk_3',['disk',['../cuda__ray_8h.html#ae9adfb9336288ac8f72ff9359cce4e95',1,'cuda_ray.h']]],
  ['disk1_4',['disk1',['../cuda__ray_8h.html#a8fa950a394ceafb915f7125ce2b4fe22',1,'cuda_ray.h']]],
  ['disk2_5',['disk2',['../cuda__ray_8h.html#a805bbdb8104d4adf0cfc8ee0c839339d',1,'cuda_ray.h']]]
];
