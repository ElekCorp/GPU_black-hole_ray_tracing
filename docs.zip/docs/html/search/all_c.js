var searchData=
[
  ['omega_5f1_0',['Omega_1',['../classkerr__black__hole.html#a89c920dc70b7f46fe2ba6a6f6f23fe0b',1,'kerr_black_hole']]],
  ['omega_5f2_1',['Omega_2',['../classkerr__black__hole.html#a08c4aa1337e264ef1be8b7dc40d1d6e0',1,'kerr_black_hole']]],
  ['omega_5f3_2',['Omega_3',['../classkerr__black__hole.html#a9525b6f0afc1aff850859d6d71494a36',1,'kerr_black_hole']]]
];
