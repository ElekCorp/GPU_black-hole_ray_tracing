var searchData=
[
  ['step_0',['step',['../cuda__ray_8h.html#a2759c4f17512e5c7473221e51b0d2611',1,'cuda_ray.h']]],
  ['step_5fsize_1',['step_size',['../cuda__ray_8h.html#a3b458fc5909707422ffbed296da06efd',1,'cuda_ray.h']]]
];
