var searchData=
[
  ['n_5foszto_0',['n_oszto',['../main_8cpp.html#a2470f7119fd95a52ef797a2f0600f2e4',1,'main.cpp']]]
];
